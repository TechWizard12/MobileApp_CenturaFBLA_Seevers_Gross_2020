//
//  Calendarscreen.swift
//  MobileApp_CenturaFBLA_Gross_Seevers_2020
//
//  Created by Colten.Seevers on 2/5/20.
//  Copyright © 2020 Colten.Seevers. All rights reserved.
//

import UIKit

class Calendarscreen: UIViewController {
   
    override func  viewDidLoad() {
    super.viewDidLoad()
    }
    @IBAction func calendarwaspressed(_ sender: Any) {if let url = URL(string: "https://calendar.google.com/calendar/embed?src=centuraps.org_oheai34mff637aassvpkdrmo74%40group.calendar.google.com&ctz=America%2FChicago") {
        UIApplication.shared.open(url)
    }
}
    @IBAction func signupwaspressed(_ sender: Any) {if let url = URL(string: "https://forms.gle/3t5Dzd18Nr8maHTU8") {
            UIApplication.shared.open(url)
        }
    }
}
