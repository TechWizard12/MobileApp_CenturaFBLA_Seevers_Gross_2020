//
//  CenturaFBLAscreen.swift
//  MobileApp_CenturaFBLA_Gross_Seevers_2020
//
//  Created by Colten.Seevers on 2/5/20.
//  Copyright © 2020 Colten.Seevers. All rights reserved.
//

import UIKit

class CenturaFBLAscreen: UIViewController {
    
    override func  viewDidLoad() {
    super.viewDidLoad()
    }
    
    @IBAction func localsocialmediawaspressed(_ sender: Any) {
        if let url = URL(string: "https://twitter.com/FblaCentura") {
            UIApplication.shared.open(url)
        }
    }
    
    @IBAction func nebraskasocialmediawaspressed(_ sender: Any) {if let url = URL(string: "https://twitter.com/NebraskaFBLA") {
            UIApplication.shared.open(url)
        }
    }
    @IBAction func nationalsocialmediawaspressed(_ sender: Any) {if let url = URL(string: "https://twitter.com/FBLA_National") {
            UIApplication.shared.open(url)
        }
    }
    @IBAction func joinwaspressed(_ sender: Any) {if let url = URL(string: "https://forms.gle/yvAb31sqTAd5rUMP7") {
        UIApplication.shared.open(url)
    }
    
}
}
