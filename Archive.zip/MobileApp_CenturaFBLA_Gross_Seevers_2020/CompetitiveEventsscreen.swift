//
//  CompetitiveEventsscreen.swift
//  MobileApp_CenturaFBLA_Gross_Seevers_2020
//
//  Created by Colten.Seevers on 2/5/20.
//  Copyright © 2020 Colten.Seevers. All rights reserved.
//

import UIKit

class CompetitiveEventsscreen: UIViewController {

    override func  viewDidLoad() {
    super.viewDidLoad()
    }

    @IBAction func listwaspressed(_ sender: Any) {if let url = URL(string: "https://www.fbla-pbl.org/fbla/competitive-events/guidelines/") {
            UIApplication.shared.open(url)
        }
    }
}

