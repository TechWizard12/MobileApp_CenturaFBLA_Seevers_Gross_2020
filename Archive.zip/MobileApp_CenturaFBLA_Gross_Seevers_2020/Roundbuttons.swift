//
//  Roundbuttons.swift
//  MobileApp_CenturaFBLA_Gross_Seevers_2020
//
//  Created by Colten.Seevers on 2/11/20.
//  Copyright © 2020 Colten.Seevers. All rights reserved.
//

import UIKit

class Roundbuttons: UIButton {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupButton()
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupButton()
    }
    
    
    private func setupButton() {
            layer.cornerRadius  = frame.size.height / 2
        }
    }
