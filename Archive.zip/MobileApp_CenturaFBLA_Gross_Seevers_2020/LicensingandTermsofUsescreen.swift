//
//  LicensingandTermsofUsescreen.swift
//  MobileApp_CenturaFBLA_Gross_Seevers_2020
//
//  Created by Colten.Seevers on 2/5/20.
//  Copyright © 2020 Colten.Seevers. All rights reserved.
//

import UIKit

class LicensingandTermsofUsescreen: UIViewController {
    
    override func  viewDidLoad() {
    super.viewDidLoad()
    }
    
    @IBAction func useragreementwaspressed(_ sender: Any) {if let url = URL(string: "https://app.termly.io/document/terms-of-use-for-ios-app/8ee4ae5d-afed-4f9c-a5c6-d570668f70c5") {UIApplication.shared.open(url)}
    }
}
