//
//  ContactUsscreen.swift
//  MobileApp_CenturaFBLA_Gross_Seevers_2020
//
//  Created by Colten.Seevers on 2/5/20.
//  Copyright © 2020 Colten.Seevers. All rights reserved.
//

import UIKit

class Contactusscreen: UIViewController {
    
    @IBAction func QAwaspressed(_ sender: Any) {if let url = URL(string: "https://forms.gle/zPM9nP4eSMDmtHBK8") {
            UIApplication.shared.open(url)
        }
    }
    @IBAction func emailbuttonpressed(_ sender: Any) {
        if let url = URL(string: "https://forms.gle/7VMmmrgNe96HSdCV9") {
            UIApplication.shared.open(url)
        }
    }
    
}
