//
//  Aboutscreen.swift
//  MobileApp_CenturaFBLA_Gross_Seevers_2020
//
//  Created by Colten.Seevers on 2/5/20.
//  Copyright © 2020 Colten.Seevers. All rights reserved.
//

import UIKit

class Aboutscreen: UIViewController {
    
    override func  viewDidLoad() {
      super.viewDidLoad()

      
    }
    @IBAction func Localwaspressed(_ sender: Any) {
        if let url = URL(string: "http://stacieloeffelholz.weebly.com/fbla.html") {
            UIApplication.shared.open(url)
        }
    }
    @IBAction func Nebraskawaspressed(_ sender: Any) {if let url = URL(string: "https://nebraskafbla.org/") {
            UIApplication.shared.open(url)
        }
    }
    @IBAction func Nationalwaspressed(_ sender: Any) {if let url = URL(string: "https://www.fbla-pbl.org/about/") {
        UIApplication.shared.open(url)
    }
}
}
